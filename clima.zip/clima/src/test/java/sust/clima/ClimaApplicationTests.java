package sust.clima;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClimaApplicationTests {

	@Test
	void contextLoads() {
	}

}

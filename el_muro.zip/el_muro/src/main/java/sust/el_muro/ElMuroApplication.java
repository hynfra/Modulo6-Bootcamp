package sust.el_muro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElMuroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElMuroApplication.class, args);
	}

}

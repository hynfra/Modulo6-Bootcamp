package sust.el_muro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElMuroApplicationTests {

	@Test
	void contextLoads() {
	}

}
